CREATE DATABASE [BD_AGENDAMENTOLAVARAPIDO]
GO

USE [BD_AGENDAMENTOLAVARAPIDO]
GO
/****** Object:  Table [dbo].[Usuario]    Script Date: 09/11/2017 18:17:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Usuario](
	[usuarioId] [int] IDENTITY(1,1) NOT NULL,
	[nome] [varchar](50) NULL,
	[cpf] [varchar](20) NULL,
	[dataNascimento] [date] NULL,
	[telefone] [varchar](50) NULL,
	[logradouro] [varchar](50) NULL,
	[numero] [varchar](50) NULL,
	[bairro] [varchar](50) NULL,
 CONSTRAINT [PK_Cliente] PRIMARY KEY CLUSTERED 
(
	[clienteId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[Cartao]    Script Date: 09/11/2017 18:17:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Cartao](
	[cartaoId] [int] IDENTITY(1,1) NOT NULL,
	[clienteId] [int] NOT NULL,
	[bandeiraDoCartao] [varchar](50) NULL,
	[NumeroDoCartao] [int] NOT NULL,
	[dataDeValidade] [date] NULL,
	[codigoSeguranca] [varchar](50) NULL,
 CONSTRAINT [PK_Cartao] PRIMARY KEY CLUSTERED 
(
	[cartaoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Cliente]  WITH CHECK ADD  CONSTRAINT [FK_Cliente_Cartao] FOREIGN KEY([cartaoId])
REFERENCES [dbo].[Cartao] ([cartaoId])
GO
ALTER TABLE [dbo].[Cliente] CHECK CONSTRAINT [FK_Cliente_Cartao]
GO

select * from Cliente