﻿using AgendamentoLavaRapido.Models;
using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class PagamentoController : Controller
    {
        // GET: Pagamento
        public ActionResult Pagamento()
        {
            return View(new Cartao());
        }

        [HttpPost]
        public ActionResult Pagamento(Cartao cartao)
        {
            cartao.Inserir(cartao);
            return RedirectToAction("Agendamento", "Agendamento");
        }
    }
}