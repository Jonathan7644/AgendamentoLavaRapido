﻿using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string email, string senha)
        {
            if (email == senha)
            {
                return RedirectToAction("Agendamento", "Agendamento");
            }
            return View();
        }

    }
}