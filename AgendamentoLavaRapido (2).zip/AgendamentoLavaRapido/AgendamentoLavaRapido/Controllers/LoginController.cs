﻿using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }

        
    }
}