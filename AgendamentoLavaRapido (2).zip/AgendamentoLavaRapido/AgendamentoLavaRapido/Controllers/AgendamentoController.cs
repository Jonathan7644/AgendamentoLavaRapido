﻿using AgendamentoLavaRapido.Models;
using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class AgendamentoController : Controller
    {
        // GET: Agendamento
        public ActionResult Agendamento()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Agendamento(Veiculo veiculo)
        {
            veiculo.Agendar(veiculo);
            return RedirectToAction("Pagamento", "Pagamento");
        }
    }
}