﻿using AgendamentoLavaRapido.Models;
using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class CadastroDeUsuarioController : Controller
    {
        // GET: CadastroDeCliente
        public ActionResult Cadastro()
        {
            return View(new Usuario());
        }

        [HttpPost]
        public ActionResult Cadastro(Usuario usuario)
        {
            usuario.Inserir(usuario);
            return RedirectToAction("Agendamento", "Agendamento");
        }
    }
}