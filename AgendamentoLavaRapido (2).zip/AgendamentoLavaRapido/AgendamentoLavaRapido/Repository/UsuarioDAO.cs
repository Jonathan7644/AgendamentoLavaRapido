﻿using AgendamentoLavaRapido.Models;
using System.Data.SqlClient;
using System.Data;

namespace AgendamentoLavaRapido.Repository
{
    public class UsuarioDAO
    {
        public void Insert(Usuario usuario)
        {
            SqlCommand comando = new SqlCommand();
            comando.CommandType = CommandType.Text;
            comando.CommandText = "INSERT INTO Usuario (nome, cpf, dataNascimento, telefone, logradouro, numero, bairro) VALUES (@nome, @cpf, @dataNascimento, @telefone, @logradouro, @numero, @bairro)";

            comando.Parameters.AddWithValue("@nome", usuario.Nome);
            comando.Parameters.AddWithValue("@cpf", usuario.Cpf);
            comando.Parameters.AddWithValue("@dataNascimento", usuario.DataNascimento);
            comando.Parameters.AddWithValue("@telefone", usuario.Telefone);
            comando.Parameters.AddWithValue("@logradouro", usuario.Logradouro);
            comando.Parameters.AddWithValue("@numero", usuario.Numero);
            comando.Parameters.AddWithValue("@bairro", usuario.Bairro);

            Conexao.Crud(comando);
        }

        public void Update(Usuario usuario)
        {
            SqlCommand comando = new SqlCommand();
            comando.CommandType = CommandType.Text;
            comando.CommandText = "UPDATE Usuario SET Nome=@Nome, cpf=@cpf, DataNascimento=@DataNascimento, Telefone=@Telefone, logradouro=@logradouro, numero=@numero, bairro=@bairro Where Id=@usuarioId"; ;

            comando.Parameters.AddWithValue("@usuarioId", usuario.Id);
            comando.Parameters.AddWithValue("@nome", usuario.Nome);
            comando.Parameters.AddWithValue("@cpf", usuario.Cpf);
            comando.Parameters.AddWithValue("@dataNascimento", usuario.DataNascimento);
            comando.Parameters.AddWithValue("@telefone", usuario.Telefone);
            comando.Parameters.AddWithValue("@logradouro", usuario.Logradouro);
            comando.Parameters.AddWithValue("@numero", usuario.Numero);
            comando.Parameters.AddWithValue("@bairro", usuario.Bairro);

            Conexao.Crud(comando);
        }
    }
}