﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AgendamentoLavaRapido.Models;

namespace AgendamentoLavaRapido.Repository
{
    public class VeiculoDAO
    {
        internal void Insert(Veiculo veiculo)
        {
            throw new NotImplementedException();
        }

        internal void Update(Veiculo veiculo)
        {
            throw new NotImplementedException();
        }
    }
}