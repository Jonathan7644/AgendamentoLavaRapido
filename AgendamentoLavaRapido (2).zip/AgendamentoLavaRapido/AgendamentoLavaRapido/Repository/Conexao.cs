﻿using System.Data.SqlClient;

namespace AgendamentoLavaRapido.Repository
{
    public class Conexao
    {
        public static SqlConnection Conectar()
        {
            string stringConexao = "Data Source=.;Initial Catalog=BD_AGENDAMENTOLAVARAPIDO;Integrated Security=True";
            SqlConnection conexao = new SqlConnection(stringConexao);
            conexao.Open();
            return conexao;
        }
        public static void Crud(SqlCommand comando)
        {
            SqlConnection con = Conectar();
            comando.Connection = con;
            comando.ExecuteNonQuery();
            con.Close();
        }
        public static SqlDataReader Selecionar(SqlCommand comando)
        {
            SqlConnection con = Conectar();
            comando.Connection = con;
            SqlDataReader dr = comando.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            return dr;
        }
    }
}