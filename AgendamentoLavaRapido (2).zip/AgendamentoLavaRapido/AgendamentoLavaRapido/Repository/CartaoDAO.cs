﻿using AgendamentoLavaRapido.Models;
using System.Data;
using System.Data.SqlClient;

namespace AgendamentoLavaRapido.Repository
{
    public class CartaoDAO
    {
        public void Insert(Cartao cartao)
        {
            SqlCommand comando = new SqlCommand();
            comando.CommandType = CommandType.Text;
            comando.CommandText = "INSERT INTO Cartao (bandeiraDoCartao, numeroDoCartao, dataDeValidade, codigoSeguranca) VALUES (@bandeiraDoCartao, @numeroDoCartao, @dataDeValidade, @codigoSeguranca)";

            comando.Parameters.AddWithValue("@bandeiraDoCartao", cartao.BandeiraDoCartao);
            comando.Parameters.AddWithValue("@numeroDoCartao", cartao.NumeroDoCartao);
            comando.Parameters.AddWithValue("@dataDeValidade", cartao.DataDeValidade);
            comando.Parameters.AddWithValue("@codigoSeguranca", cartao.CodigoSeguranca);
           
            Conexao.Crud(comando);
        }

        public void Update(Cartao cartao)
        {
            SqlCommand comando = new SqlCommand();
            comando.CommandType = CommandType.Text;
            comando.CommandText = "UPDATE Cartao SET bandeiraDoCartao=@bandeiraDoCartao, numeroDoCartao=@numeroDoCartao, dataDeValidade=@dataDeValidade, codigoSeguranca=@codigoSeguranca Where Id=@cartaoId"; ;

            comando.Parameters.AddWithValue("@cartaoId", cartao.Id);
            comando.Parameters.AddWithValue("@bandeiraDoCartao", cartao.BandeiraDoCartao);
            comando.Parameters.AddWithValue("@numeroDoCartao", cartao.NumeroDoCartao);
            comando.Parameters.AddWithValue("@dataDeValidade", cartao.DataDeValidade);
            comando.Parameters.AddWithValue("@codigoSeguranca", cartao.CodigoSeguranca);

            Conexao.Crud(comando);
        }
    }
}