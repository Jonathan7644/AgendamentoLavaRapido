﻿using AgendamentoLavaRapido.Repository;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace AgendamentoLavaRapido.Models
{
    public class Cartao
    {
        [Key]
        public int Id { get; set; }

        [DisplayName("Bandeira do Cartão")]
        public string BandeiraDoCartao { get; set; }

        [DisplayName("Número do Cartão")]
        public int NumeroDoCartao { get; set; }

        [DisplayName("Data de Validade")]
        public DateTime DataDeValidade { get; set; }

        [DisplayName("Código de Segurança")]
        public string CodigoSeguranca { get; set; }

        CartaoDAO cartaoDAO = new CartaoDAO();

        public void Inserir(Cartao cartao)
        {
            if (Id == 0)
            {
                cartaoDAO.Insert(this);
            }
            else
            {
                cartaoDAO.Update(this);
            }
        }
    }
}