﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AgendamentoLavaRapido.Models
{
    public class Lavagem
    {
        public string LavagemSimples { get; set; }
        public string LavagemCompleta { get; set; }
        public string LavagemEspecial { get; set; }
    }
}