﻿using AgendamentoLavaRapido.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AgendamentoLavaRapido.Models
{
    public class Veiculo:Lavagem
    {
        public int Id { get; set; }
        public string Moto { get; set; }
        public string CarroPequeno { get; set; }
        public string CarroMedio { get; set; }
        public string CarroGrande { get; set; }

        VeiculoDAO veiculoDAO = new VeiculoDAO();

        public void Agendar(Veiculo veiculo)
        {

            if (Id == 0)
            {
                veiculoDAO.Insert(this);
            }
            else
            {
                veiculoDAO.Update(this);
            }
        }
    }
}