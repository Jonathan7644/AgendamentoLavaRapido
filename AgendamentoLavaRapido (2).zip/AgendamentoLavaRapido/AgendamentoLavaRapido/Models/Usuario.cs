﻿using AgendamentoLavaRapido.Repository;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace AgendamentoLavaRapido.Models
{
    public class Usuario
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [DisplayName("Nome completo")]
        public string Nome { get; set; }

        [Required]
        [DisplayName("CPF")]
        public string Cpf { get; set; }

        [Required]
        [DisplayName("Data de Nascimento")]
        public DateTime DataNascimento { get; set; }

        [Required]
        [DisplayName("Telefone")]
        public string Telefone { get; set; }

        [Required]
        [DisplayName("Av, Rua, Trav...")]
        public string Logradouro { get; set; }

        [Required]
        [DisplayName("Número")]
        public string Numero { get; set; }

        [Required]
        [DisplayName("Bairro")]
        public string Bairro { get; set; }

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        public void Inserir(Usuario usuario)
        {

            if (Id == 0)
            {
                usuarioDAO.Insert(this);
            }
            else
            {
                usuarioDAO.Update(this);
            }
        }
    }
}