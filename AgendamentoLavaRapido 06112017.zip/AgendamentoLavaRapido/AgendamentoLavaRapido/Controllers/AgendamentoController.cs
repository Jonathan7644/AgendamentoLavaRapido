﻿using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class AgendamentoController : Controller
    {
        // GET: Agendamento
        public ActionResult Agendamento()
        {
            return View();
        }
    }
}