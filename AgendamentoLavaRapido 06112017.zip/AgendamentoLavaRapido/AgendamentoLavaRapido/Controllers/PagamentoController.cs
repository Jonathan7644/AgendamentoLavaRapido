﻿using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class PagamentoController : Controller
    {
        // GET: Pagamento
        public ActionResult Pagamento()
        {
            return View();
        }
    }
}