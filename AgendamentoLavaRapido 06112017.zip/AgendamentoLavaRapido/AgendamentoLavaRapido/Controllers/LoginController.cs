﻿using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string login, string senha)
        {
            if (login == senha)
            {
                return RedirectToAction("Agendamento", "Agendamento");
            }
            return View();
        }
    }
}