﻿using AgendamentoLavaRapido.Models;
using AgendamentoLavaRapido.Repository;
using System;
using System.Web.Mvc;

namespace AgendamentoLavaRapido.Controllers
{
    public class CadastroDeClienteController : Controller
    {
        // GET: CadastroDeCliente
        public ActionResult Cadastro()
        {
            return View(new Cliente());
        }

        [HttpPost]
        public ActionResult Cadastro (Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                Random r = new Random();
                cliente.Id = r.Next(1, 99999);
                Banco.Clientes.Add(cliente);
                @ViewBag.Mensagem = "Cliente cadastrado com Sucesso";
                return RedirectToAction("Agendamento", "Agendamento");
            }
            return View(cliente);
        }
    }
}