﻿using AgendamentoLavaRapido.Models;
using System.Collections.Generic;

namespace AgendamentoLavaRapido.Repository
{
    public class Banco
    {
        public static IList<Cliente>
            Clientes = new List<Cliente>();
    }
}