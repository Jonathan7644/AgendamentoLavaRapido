﻿using System;
using System.ComponentModel;

namespace AgendamentoLavaRapido.Models
{
    public class Cartao
    {
        [DisplayName("Bandeira do Cartão")]
        public string BandeiraDoCartao { get; set; }

        [DisplayName("Número do Cartão")]
        public int NumeroDoCartao { get; set; }

        [DisplayName("Data de Validade")]
        public DateTime DataDeValidade { get; set; }

        [DisplayName("Código de Segurança")]
        public string CodigoSeguranca { get; set; }
    }
}